import { type Adjustments, filterString } from "./mavens"

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.crossOrigin = "anonymous"
    img.onload = () => resolve(img)
    img.onerror = reject
    img.src = src
  })
}

/** Rotate the image by 90 or -90 degrees, returning a new data URL. */
export async function rotateImage(src: string, degrees: 90 | -90): Promise<string> {
  const img = await loadImage(src)
  const canvas = document.createElement("canvas")
  canvas.width = img.height
  canvas.height = img.width
  const ctx = canvas.getContext("2d")!
  ctx.translate(canvas.width / 2, canvas.height / 2)
  ctx.rotate((degrees * Math.PI) / 180)
  ctx.drawImage(img, -img.width / 2, -img.height / 2)
  return canvas.toDataURL("image/png")
}

/** Flip the image horizontally or vertically. */
export async function flipImage(src: string, axis: "horizontal" | "vertical"): Promise<string> {
  const img = await loadImage(src)
  const canvas = document.createElement("canvas")
  canvas.width = img.width
  canvas.height = img.height
  const ctx = canvas.getContext("2d")!
  if (axis === "horizontal") {
    ctx.translate(canvas.width, 0)
    ctx.scale(-1, 1)
  } else {
    ctx.translate(0, canvas.height)
    ctx.scale(1, -1)
  }
  ctx.drawImage(img, 0, 0)
  return canvas.toDataURL("image/png")
}

export type CropRect = { x: number; y: number; width: number; height: number }

/** Crop the image to the given rect expressed as fractions (0..1) of the source. */
export async function cropImage(src: string, rect: CropRect): Promise<string> {
  const img = await loadImage(src)
  const sx = Math.round(rect.x * img.width)
  const sy = Math.round(rect.y * img.height)
  const sw = Math.max(1, Math.round(rect.width * img.width))
  const sh = Math.max(1, Math.round(rect.height * img.height))
  const canvas = document.createElement("canvas")
  canvas.width = sw
  canvas.height = sh
  const ctx = canvas.getContext("2d")!
  ctx.drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh)
  return canvas.toDataURL("image/png")
}

/** Render the image with baked-in adjustment filters and export as a data URL. */
export async function exportImage(
  src: string,
  adjustments: Adjustments,
  format: "png" | "jpeg",
): Promise<string> {
  const img = await loadImage(src)
  const canvas = document.createElement("canvas")
  canvas.width = img.width
  canvas.height = img.height
  const ctx = canvas.getContext("2d")!
  if (format === "jpeg") {
    ctx.fillStyle = "#ffffff"
    ctx.fillRect(0, 0, canvas.width, canvas.height)
  }
  ctx.filter = filterString(adjustments)
  ctx.drawImage(img, 0, 0)
  return canvas.toDataURL(format === "png" ? "image/png" : "image/jpeg", 0.92)
}
