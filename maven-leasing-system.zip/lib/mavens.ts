export type Adjustments = {
  brightness: number
  contrast: number
  saturation: number
  sepia: number
  grayscale: number
  hueRotate: number
  blur: number
  invert: number
}

export const NEUTRAL_ADJUSTMENTS: Adjustments = {
  brightness: 100,
  contrast: 100,
  saturation: 100,
  sepia: 0,
  grayscale: 0,
  hueRotate: 0,
  blur: 0,
  invert: 0,
}

export type MavenTier = "common" | "elite" | "mythic"

export type Maven = {
  id: string
  name: string
  role: string
  feel: string
  outputStyle: string
  tier: MavenTier
  /** oklch accent color for this maven */
  accent: string
  /** lucide icon name */
  icon: string
  /** signature edit preset applied when leased */
  preset: Adjustments
}

export const MAVENS: Maven[] = [
  {
    id: "architect-leaser",
    name: "Architect-Leaser",
    role: "Structural intelligence authority",
    feel: "Cold precision, structural inevitability",
    outputStyle: "Clean edges, cool tone, engineered clarity",
    tier: "elite",
    accent: "oklch(0.7 0.13 230)",
    icon: "Boxes",
    preset: { ...NEUTRAL_ADJUSTMENTS, contrast: 122, saturation: 84, brightness: 100, hueRotate: -8 },
  },
  {
    id: "god-conductor",
    name: "God Conductor",
    role: "Perception orchestration authority",
    feel: "Cinematic control room, orchestral command",
    outputStyle: "Unified render reality, rich and warm",
    tier: "mythic",
    accent: "oklch(0.82 0.14 78)",
    icon: "Radio",
    preset: { ...NEUTRAL_ADJUSTMENTS, contrast: 116, saturation: 122, brightness: 103, sepia: 8 },
  },
  {
    id: "compiler-priest",
    name: "Compiler-Priest",
    role: "Transformation authority",
    feel: "Ritual precision, strict transformation logic",
    outputStyle: "Validated monochrome contracts",
    tier: "elite",
    accent: "oklch(0.75 0.02 285)",
    icon: "Terminal",
    preset: { ...NEUTRAL_ADJUSTMENTS, grayscale: 42, contrast: 128, brightness: 101 },
  },
  {
    id: "market-auditor",
    name: "Market Auditor",
    role: "Systems + business realism layer",
    feel: "Skeptical intelligence, business gravity",
    outputStyle: "Flat, honest, unembellished exposure",
    tier: "common",
    accent: "oklch(0.68 0.15 150)",
    icon: "LineChart",
    preset: { ...NEUTRAL_ADJUSTMENTS, contrast: 96, saturation: 90, brightness: 98 },
  },
  {
    id: "feral-signal-refiner",
    name: "Feral Signal Refiner",
    role: "Aesthetic + emotional intelligence layer",
    feel: "Intuition amplifier, taste compression engine",
    outputStyle: "Punchy, warm glow, heightened felt quality",
    tier: "mythic",
    accent: "oklch(0.66 0.2 20)",
    icon: "Sparkles",
    preset: { ...NEUTRAL_ADJUSTMENTS, saturation: 136, contrast: 109, brightness: 105, sepia: 6 },
  },
]

export function filterString(a: Adjustments): string {
  return [
    `brightness(${a.brightness}%)`,
    `contrast(${a.contrast}%)`,
    `saturate(${a.saturation}%)`,
    `sepia(${a.sepia}%)`,
    `grayscale(${a.grayscale}%)`,
    `hue-rotate(${a.hueRotate}deg)`,
    `blur(${a.blur}px)`,
    `invert(${a.invert}%)`,
  ].join(" ")
}

export const TIER_LABEL: Record<MavenTier, string> = {
  common: "Common Governor",
  elite: "Elite Governor",
  mythic: "Mythic Governor",
}
