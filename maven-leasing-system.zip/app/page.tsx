import { MavenStudio } from "@/components/maven-studio"

export default function Page() {
  return <MavenStudio />
}
