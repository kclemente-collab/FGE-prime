"use client"

import { ControlSlider } from "@/components/control-slider"
import { type Adjustments, NEUTRAL_ADJUSTMENTS } from "@/lib/mavens"

export function AdjustmentPanel({
  adjustments,
  onChange,
}: {
  adjustments: Adjustments
  onChange: (next: Adjustments) => void
}) {
  const set = (key: keyof Adjustments) => (value: number) => onChange({ ...adjustments, [key]: value })

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-foreground">Signal Adjustments</h2>
        <button
          type="button"
          onClick={() => onChange({ ...NEUTRAL_ADJUSTMENTS })}
          className="text-[11px] font-medium text-muted-foreground transition-colors hover:text-primary"
        >
          Reset
        </button>
      </div>
      <div className="space-y-3.5">
        <ControlSlider label="Brightness" value={adjustments.brightness} min={0} max={200} unit="%" neutral={100} onChange={set("brightness")} />
        <ControlSlider label="Contrast" value={adjustments.contrast} min={0} max={200} unit="%" neutral={100} onChange={set("contrast")} />
        <ControlSlider label="Saturation" value={adjustments.saturation} min={0} max={200} unit="%" neutral={100} onChange={set("saturation")} />
        <ControlSlider label="Warmth (Sepia)" value={adjustments.sepia} min={0} max={100} unit="%" neutral={0} onChange={set("sepia")} />
        <ControlSlider label="Grayscale" value={adjustments.grayscale} min={0} max={100} unit="%" neutral={0} onChange={set("grayscale")} />
        <ControlSlider label="Hue Rotate" value={adjustments.hueRotate} min={-180} max={180} unit="°" neutral={0} onChange={set("hueRotate")} />
        <ControlSlider label="Blur" value={adjustments.blur} min={0} max={20} step={0.1} unit="px" neutral={0} onChange={set("blur")} />
        <ControlSlider label="Invert" value={adjustments.invert} min={0} max={100} unit="%" neutral={0} onChange={set("invert")} />
      </div>
    </div>
  )
}
