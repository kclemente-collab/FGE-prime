"use client"

import { useCallback, useRef, useState } from "react"
import { ImageUp } from "lucide-react"

export function UploadZone({ onImage }: { onImage: (src: string) => void }) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = useState(false)

  const handleFile = useCallback(
    (file: File | undefined) => {
      if (!file || !file.type.startsWith("image/")) return
      const reader = new FileReader()
      reader.onload = () => onImage(reader.result as string)
      reader.readAsDataURL(file)
    },
    [onImage],
  )

  return (
    <div className="flex h-full w-full items-center justify-center p-6">
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault()
          setDragging(true)
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault()
          setDragging(false)
          handleFile(e.dataTransfer.files?.[0])
        }}
        className={`group flex w-full max-w-xl flex-col items-center justify-center gap-4 rounded-2xl border-2 border-dashed p-12 text-center transition-colors ${
          dragging
            ? "border-primary bg-primary/5"
            : "border-border bg-card/40 hover:border-primary/60 hover:bg-card/70"
        }`}
      >
        <span className="flex size-16 items-center justify-center rounded-full bg-primary/10 text-primary transition-transform group-hover:scale-105">
          <ImageUp className="size-7" aria-hidden="true" />
        </span>
        <span className="space-y-1">
          <span className="block text-lg font-semibold text-foreground">Load an image into the chamber</span>
          <span className="block text-sm text-muted-foreground text-pretty">
            Drop a photo here or click to browse. Your image never leaves the browser.
          </span>
        </span>
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          className="sr-only"
          onChange={(e) => handleFile(e.target.files?.[0])}
        />
      </button>
    </div>
  )
}
