"use client"

import { Boxes, Radio, Terminal, LineChart, Sparkles, type LucideIcon } from "lucide-react"
import { MAVENS, TIER_LABEL, type Maven } from "@/lib/mavens"

const ICONS: Record<string, LucideIcon> = {
  Boxes,
  Radio,
  Terminal,
  LineChart,
  Sparkles,
}

export function MavenSelector({
  activeId,
  onLease,
}: {
  activeId: string | null
  onLease: (maven: Maven) => void
}) {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-foreground">Maven Leasing Layer</h2>
        <span className="text-[11px] uppercase tracking-wider text-muted-foreground">Felt selection</span>
      </div>
      <p className="text-xs text-muted-foreground text-pretty">
        Lease a trophied intelligence persona. Each governor holds the canvas with its own control signature.
      </p>
      <ul className="grid grid-cols-1 gap-2.5">
        {MAVENS.map((maven) => {
          const Icon = ICONS[maven.icon] ?? Boxes
          const active = maven.id === activeId
          return (
            <li key={maven.id}>
              <button
                type="button"
                onClick={() => onLease(maven)}
                aria-pressed={active}
                className={`relative flex w-full gap-3 rounded-xl border p-3 text-left transition-all ${
                  active
                    ? "border-primary bg-primary/5 shadow-[0_0_0_1px_var(--primary)]"
                    : "border-border bg-card/60 hover:border-primary/50 hover:bg-card"
                }`}
              >
                <span
                  className="mt-0.5 flex size-9 shrink-0 items-center justify-center rounded-lg"
                  style={{ backgroundColor: `color-mix(in oklch, ${maven.accent} 18%, transparent)`, color: maven.accent }}
                >
                  <Icon className="size-4" aria-hidden="true" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="flex items-center justify-between gap-2">
                    <span className="truncate text-sm font-semibold text-foreground">{maven.name}</span>
                    <TierBadge tier={maven.tier} />
                  </span>
                  <span className="mt-0.5 block truncate text-xs text-muted-foreground">{maven.role}</span>
                  <span className="mt-1 block text-[11px] italic text-muted-foreground/80 text-pretty">
                    {maven.feel}
                  </span>
                </span>
                {active && (
                  <span className="absolute right-2 top-2 rounded-full bg-primary px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide text-primary-foreground">
                    Leased
                  </span>
                )}
              </button>
            </li>
          )
        })}
      </ul>
    </div>
  )
}

function TierBadge({ tier }: { tier: Maven["tier"] }) {
  const styles: Record<Maven["tier"], string> = {
    common: "border-border text-muted-foreground",
    elite: "border-chart-2/50 text-chart-2",
    mythic: "border-primary/50 text-primary",
  }
  return (
    <span
      className={`shrink-0 rounded-full border px-1.5 py-0.5 text-[9px] font-medium uppercase tracking-wide ${styles[tier]}`}
      title={TIER_LABEL[tier]}
    >
      {tier}
    </span>
  )
}
