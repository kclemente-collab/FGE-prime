"use client"

import { useRef, useState } from "react"
import { Check, X } from "lucide-react"
import { type Adjustments, filterString } from "@/lib/mavens"
import type { CropRect } from "@/lib/image-ops"

type Sel = { x: number; y: number; w: number; h: number }

export function EditorCanvas({
  src,
  adjustments,
  cropMode,
  onApplyCrop,
  onCancelCrop,
}: {
  src: string
  adjustments: Adjustments
  cropMode: boolean
  onApplyCrop: (rect: CropRect) => void
  onCancelCrop: () => void
}) {
  const wrapperRef = useRef<HTMLDivElement>(null)
  const [sel, setSel] = useState<Sel | null>(null)
  const [drawing, setDrawing] = useState(false)
  const startRef = useRef<{ x: number; y: number } | null>(null)

  const toFraction = (clientX: number, clientY: number) => {
    const rect = wrapperRef.current!.getBoundingClientRect()
    const x = Math.min(1, Math.max(0, (clientX - rect.left) / rect.width))
    const y = Math.min(1, Math.max(0, (clientY - rect.top) / rect.height))
    return { x, y }
  }

  const handleDown = (e: React.PointerEvent) => {
    if (!cropMode) return
    e.currentTarget.setPointerCapture(e.pointerId)
    const p = toFraction(e.clientX, e.clientY)
    startRef.current = p
    setSel({ x: p.x, y: p.y, w: 0, h: 0 })
    setDrawing(true)
  }

  const handleMove = (e: React.PointerEvent) => {
    if (!drawing || !startRef.current) return
    const p = toFraction(e.clientX, e.clientY)
    const s = startRef.current
    setSel({
      x: Math.min(s.x, p.x),
      y: Math.min(s.y, p.y),
      w: Math.abs(p.x - s.x),
      h: Math.abs(p.y - s.y),
    })
  }

  const handleUp = () => setDrawing(false)

  const apply = () => {
    if (sel && sel.w > 0.02 && sel.h > 0.02) {
      onApplyCrop({ x: sel.x, y: sel.y, width: sel.w, height: sel.h })
    }
    setSel(null)
  }

  const cancel = () => {
    setSel(null)
    onCancelCrop()
  }

  return (
    <div className="flex h-full w-full items-center justify-center p-4 sm:p-8">
      <div ref={wrapperRef} className="relative inline-block max-h-full max-w-full leading-none">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={src || "/placeholder.svg"}
          alt="Editing canvas"
          draggable={false}
          className="block max-h-[70vh] max-w-full select-none rounded-lg object-contain shadow-2xl"
          style={{ filter: filterString(adjustments) }}
        />

        {cropMode && (
          <div
            className="absolute inset-0 cursor-crosshair touch-none"
            onPointerDown={handleDown}
            onPointerMove={handleMove}
            onPointerUp={handleUp}
          >
            <div className="absolute inset-0 rounded-lg bg-background/60" />
            {sel && sel.w > 0 && sel.h > 0 && (
              <div
                className="absolute border-2 border-primary shadow-[0_0_0_9999px_var(--background)]/0"
                style={{
                  left: `${sel.x * 100}%`,
                  top: `${sel.y * 100}%`,
                  width: `${sel.w * 100}%`,
                  height: `${sel.h * 100}%`,
                  boxShadow: "0 0 0 9999px color-mix(in oklch, var(--background) 55%, transparent)",
                }}
              >
                <span className="absolute -top-6 left-0 rounded bg-primary px-1.5 py-0.5 text-[10px] font-medium text-primary-foreground">
                  Crop region
                </span>
              </div>
            )}
            <div className="absolute bottom-3 left-1/2 flex -translate-x-1/2 gap-2">
              <button
                type="button"
                onClick={apply}
                className="flex items-center gap-1 rounded-md bg-primary px-3 py-1.5 text-xs font-semibold text-primary-foreground transition-opacity hover:opacity-90"
              >
                <Check className="size-3.5" aria-hidden="true" /> Apply
              </button>
              <button
                type="button"
                onClick={cancel}
                className="flex items-center gap-1 rounded-md border border-border bg-card px-3 py-1.5 text-xs font-semibold text-foreground transition-colors hover:bg-accent"
              >
                <X className="size-3.5" aria-hidden="true" /> Cancel
              </button>
            </div>
            {!sel && (
              <span className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 rounded-md bg-card/90 px-3 py-1.5 text-xs text-muted-foreground">
                Drag to select a crop region
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
