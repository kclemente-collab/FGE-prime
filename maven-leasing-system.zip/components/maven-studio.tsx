"use client"

import { useState } from "react"
import {
  RotateCcw,
  RotateCw,
  FlipHorizontal,
  FlipVertical,
  Crop,
  Download,
  ImagePlus,
  Undo2,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { UploadZone } from "@/components/upload-zone"
import { EditorCanvas } from "@/components/editor-canvas"
import { MavenSelector } from "@/components/maven-selector"
import { AdjustmentPanel } from "@/components/adjustment-panel"
import { type Adjustments, NEUTRAL_ADJUSTMENTS, type Maven } from "@/lib/mavens"
import { cropImage, exportImage, flipImage, rotateImage, type CropRect } from "@/lib/image-ops"

export function MavenStudio() {
  const [src, setSrc] = useState<string | null>(null)
  const [originalSrc, setOriginalSrc] = useState<string | null>(null)
  const [adjustments, setAdjustments] = useState<Adjustments>({ ...NEUTRAL_ADJUSTMENTS })
  const [activeMaven, setActiveMaven] = useState<Maven | null>(null)
  const [cropMode, setCropMode] = useState(false)
  const [busy, setBusy] = useState(false)
  const [format, setFormat] = useState<"png" | "jpeg">("png")

  const loadImage = (dataUrl: string) => {
    setSrc(dataUrl)
    setOriginalSrc(dataUrl)
    setAdjustments({ ...NEUTRAL_ADJUSTMENTS })
    setActiveMaven(null)
    setCropMode(false)
  }

  const leaseMaven = (maven: Maven) => {
    if (activeMaven?.id === maven.id) {
      setActiveMaven(null)
      setAdjustments({ ...NEUTRAL_ADJUSTMENTS })
    } else {
      setActiveMaven(maven)
      setAdjustments({ ...maven.preset })
    }
  }

  const withImage = async (fn: (s: string) => Promise<string>) => {
    if (!src) return
    setBusy(true)
    try {
      setSrc(await fn(src))
    } finally {
      setBusy(false)
    }
  }

  const handleCrop = async (rect: CropRect) => {
    await withImage((s) => cropImage(s, rect))
    setCropMode(false)
  }

  const handleExport = async () => {
    if (!src) return
    setBusy(true)
    try {
      const url = await exportImage(src, adjustments, format)
      const a = document.createElement("a")
      a.href = url
      a.download = `maven-artifact.${format}`
      a.click()
    } finally {
      setBusy(false)
    }
  }

  const revert = () => {
    if (!originalSrc) return
    setSrc(originalSrc)
    setAdjustments({ ...NEUTRAL_ADJUSTMENTS })
    setActiveMaven(null)
    setCropMode(false)
  }

  return (
    <div className="flex h-dvh flex-col bg-background text-foreground">
      {/* Header */}
      <header className="flex items-center justify-between gap-3 border-b border-border px-4 py-3 sm:px-6">
        <div className="flex items-center gap-3">
          <div className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Crop className="size-4" aria-hidden="true" />
          </div>
          <div className="leading-tight">
            <h1 className="text-sm font-bold tracking-tight text-foreground">MAVEN Studio OS</h1>
            <p className="text-[11px] text-muted-foreground">Leaseable intelligence · live canvas chamber</p>
          </div>
        </div>
        {src && (
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={revert} disabled={busy}>
              <Undo2 className="size-4" aria-hidden="true" />
              <span className="hidden sm:inline">Revert</span>
            </Button>
            <label className="sr-only" htmlFor="fmt">
              Export format
            </label>
            <select
              id="fmt"
              value={format}
              onChange={(e) => setFormat(e.target.value as "png" | "jpeg")}
              className="h-8 rounded-md border border-border bg-card px-2 text-xs text-foreground"
            >
              <option value="png">PNG</option>
              <option value="jpeg">JPG</option>
            </select>
            <Button size="sm" onClick={handleExport} disabled={busy}>
              <Download className="size-4" aria-hidden="true" />
              <span className="hidden sm:inline">Export</span>
            </Button>
          </div>
        )}
      </header>

      <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
        {/* Left rail: Mavens */}
        <aside className="order-2 shrink-0 overflow-y-auto border-t border-border p-4 lg:order-1 lg:w-72 lg:border-r lg:border-t-0">
          <MavenSelector activeId={activeMaven?.id ?? null} onLease={leaseMaven} />
        </aside>

        {/* Center: canvas */}
        <main className="order-1 flex min-h-0 flex-1 flex-col lg:order-2">
          {src ? (
            <>
              <div className="flex flex-wrap items-center gap-1.5 border-b border-border px-3 py-2">
                <ToolButton label="Rotate left" onClick={() => withImage((s) => rotateImage(s, -90))} disabled={busy || cropMode}>
                  <RotateCcw className="size-4" aria-hidden="true" />
                </ToolButton>
                <ToolButton label="Rotate right" onClick={() => withImage((s) => rotateImage(s, 90))} disabled={busy || cropMode}>
                  <RotateCw className="size-4" aria-hidden="true" />
                </ToolButton>
                <ToolButton label="Flip horizontal" onClick={() => withImage((s) => flipImage(s, "horizontal"))} disabled={busy || cropMode}>
                  <FlipHorizontal className="size-4" aria-hidden="true" />
                </ToolButton>
                <ToolButton label="Flip vertical" onClick={() => withImage((s) => flipImage(s, "vertical"))} disabled={busy || cropMode}>
                  <FlipVertical className="size-4" aria-hidden="true" />
                </ToolButton>
                <span className="mx-1 h-5 w-px bg-border" />
                <Button
                  variant={cropMode ? "default" : "outline"}
                  size="sm"
                  onClick={() => setCropMode((v) => !v)}
                  disabled={busy}
                >
                  <Crop className="size-4" aria-hidden="true" />
                  Crop
                </Button>
                <span className="mx-1 h-5 w-px bg-border" />
                <Button variant="ghost" size="sm" onClick={() => setSrc(null)}>
                  <ImagePlus className="size-4" aria-hidden="true" />
                  <span className="hidden sm:inline">New image</span>
                </Button>
                {activeMaven && (
                  <span className="ml-auto text-[11px] text-muted-foreground">
                    Leased: <span className="font-medium text-primary">{activeMaven.name}</span>
                  </span>
                )}
              </div>
              <div className="relative min-h-0 flex-1 overflow-hidden bg-[radial-gradient(circle_at_center,color-mix(in_oklch,var(--foreground)_4%,transparent),transparent_70%)]">
                <EditorCanvas
                  src={src}
                  adjustments={adjustments}
                  cropMode={cropMode}
                  onApplyCrop={handleCrop}
                  onCancelCrop={() => setCropMode(false)}
                />
              </div>
            </>
          ) : (
            <UploadZone onImage={loadImage} />
          )}
        </main>

        {/* Right rail: adjustments */}
        <aside className="order-3 shrink-0 overflow-y-auto border-t border-border p-4 lg:w-72 lg:border-l lg:border-t-0">
          {src ? (
            <AdjustmentPanel adjustments={adjustments} onChange={setAdjustments} />
          ) : (
            <div className="text-xs text-muted-foreground text-pretty">
              Adjustments unlock once an image is loaded into the chamber.
            </div>
          )}
        </aside>
      </div>
    </div>
  )
}

function ToolButton({
  label,
  onClick,
  disabled,
  children,
}: {
  label: string
  onClick: () => void
  disabled?: boolean
  children: React.ReactNode
}) {
  return (
    <Button variant="ghost" size="icon" onClick={onClick} disabled={disabled} aria-label={label} title={label}>
      {children}
    </Button>
  )
}
