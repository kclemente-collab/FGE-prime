"use client"

export function ControlSlider({
  label,
  value,
  min,
  max,
  step = 1,
  unit = "",
  neutral,
  onChange,
}: {
  label: string
  value: number
  min: number
  max: number
  step?: number
  unit?: string
  neutral: number
  onChange: (value: number) => void
}) {
  const changed = value !== neutral
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-xs">
        <span className="font-medium text-foreground">{label}</span>
        <span className={changed ? "text-primary tabular-nums" : "text-muted-foreground tabular-nums"}>
          {value}
          {unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        aria-label={label}
        className="maven-range w-full"
      />
    </div>
  )
}
