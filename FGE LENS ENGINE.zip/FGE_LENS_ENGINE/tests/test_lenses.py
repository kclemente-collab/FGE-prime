from src.lenses import Lens, normalize_weights, apply_lenses

def test_normalization():
    lenses = [Lens("A", 2.0, 0.5), Lens("B", 2.0, 0.5)]
    norm = normalize_weights(lenses)
    assert abs(norm[0].weight - 0.5) < 1e-6
    assert abs(norm[1].weight - 0.5) < 1e-6

def test_apply_lenses():
    lenses = [Lens("A", 1.0, 0.5), Lens("B", 1.0, 0.5)]
    values = {"A": 10, "B": 0}
    result = apply_lenses(lenses, values)
    assert 4.9 < result < 5.1
