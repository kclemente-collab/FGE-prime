from src.lenses import Lens
from src.compiler_v2 import resolve

def test_resolve_structure():
    lenses = [Lens("A", 1.0, 0.9), Lens("B", 1.0, 0.8)]
    result = resolve(lenses, {"A": 10, "B": 0})
    assert "output" in result
    assert "bias" in result
    assert "conflict_matrix" in result

def test_bias_logic():
    lenses = [Lens("A", 1.0, 0.9), Lens("B", 1.0, 0.9)]
    result = resolve(lenses, {})
    assert result["bias"] in {"dominant", "balanced", "distributed"}
