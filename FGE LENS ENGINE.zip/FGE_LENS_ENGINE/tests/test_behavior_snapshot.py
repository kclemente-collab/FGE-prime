"""
Behavior snapshot lock with human-readable diffs.

Workflow:
  1. First run: no golden file exists yet -> test writes one and FAILS
     on purpose, printing the new snapshot so you can review it.
  2. Review the printed snapshot. If it looks correct, the file is
     already saved -> just run pytest again and it will PASS.
  3. Any future change to engine behavior will FAIL this test and
     print a field-by-field diff (old vs new), not just a hash.
  4. If the change was intentional, delete the golden file (or run
     with REGEN_SNAPSHOT=1) to accept the new behavior as the new lock.
"""
import json
import os
from src.lenses import Lens
from src.compiler_v2 import resolve

GOLDEN_PATH = os.path.join(os.path.dirname(__file__), "snapshots", "lens_engine_v1.json")


def _snapshot():
    lenses = [
        Lens("A", 1.0, 0.8, volatility=0.3),
        Lens("B", 1.0, 0.4, volatility=0.1),
        Lens("C", 1.0, 0.6, volatility=0.5),
    ]
    values = {"A": 10, "B": 5, "C": 0}
    result = resolve(lenses, values)
    return {
        "output": result["output"],
        "bias": result["bias"],
        "conflict_matrix": result["conflict_matrix"],
    }


def _diff(old: dict, new: dict, path=""):
    """Yield human-readable lines describing every difference between old and new."""
    lines = []
    keys = set(old.keys()) | set(new.keys())
    for key in sorted(keys):
        full_path = f"{path}.{key}" if path else key
        if key not in old:
            lines.append(f"  + {full_path} added: {new[key]!r}")
        elif key not in new:
            lines.append(f"  - {full_path} removed (was {old[key]!r})")
        elif isinstance(old[key], dict) and isinstance(new[key], dict):
            lines.extend(_diff(old[key], new[key], full_path))
        elif old[key] != new[key]:
            lines.append(f"  ~ {full_path}: {old[key]!r} -> {new[key]!r}")
    return lines


def test_behavior_snapshot_lock():
    current = _snapshot()

    if not os.path.exists(GOLDEN_PATH):
        os.makedirs(os.path.dirname(GOLDEN_PATH), exist_ok=True)
        with open(GOLDEN_PATH, "w") as f:
            json.dump(current, f, indent=2, sort_keys=True)
        print(f"\n[SNAPSHOT CREATED] No golden file existed. Wrote one to:\n  {GOLDEN_PATH}")
        print("Review it. If correct, just re-run pytest -- it will pass next time.")
        assert False, "First run: golden snapshot created, review it and re-run."

    with open(GOLDEN_PATH) as f:
        golden = json.load(f)

    if current != golden:
        diff_lines = _diff(golden, current)
        diff_report = "\n".join(diff_lines) if diff_lines else "  (values differ but no field-level diff found -- check types)"
        message = (
            "\n[BEHAVIOR DRIFT DETECTED] Engine output no longer matches the locked snapshot.\n"
            f"Golden file: {GOLDEN_PATH}\n"
            "Diff (golden -> current):\n"
            f"{diff_report}\n\n"
            "If this change was intentional, delete the golden file and re-run to accept the new behavior.\n"
            "If it was NOT intentional, you just caught a regression."
        )
        assert False, message
