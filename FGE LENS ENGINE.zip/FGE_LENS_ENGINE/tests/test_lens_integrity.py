from src.lenses import Lens, apply_lenses, normalize_weights
from src.compiler_v2 import resolve

def test_apply_lenses_order_independence():
    lenses_a = [Lens("A", 2.0, 0.5), Lens("B", 1.0, 0.5)]
    lenses_b = list(reversed(lenses_a))
    values = {"A": 10, "B": 0}
    result_a = apply_lenses(lenses_a, values)
    result_b = apply_lenses(lenses_b, values)
    assert abs(result_a - result_b) < 1e-9

def test_weight_normalization_bounds():
    lenses = [Lens("A", 1000.0, 0.5), Lens("B", 1.0, 0.5)]
    norm = normalize_weights(lenses)
    total = sum(l.weight for l in norm)
    assert abs(total - 1.0) < 1e-9
    assert all(0.0 <= l.weight <= 1.0 for l in norm)

def test_bias_determinism():
    lenses = [Lens("A", 1.0, 0.9), Lens("B", 1.0, 0.9)]
    r1 = resolve(lenses, {})
    r2 = resolve(lenses, {})
    assert r1["bias"] == r2["bias"]

def test_volatility_affects_conflict_score():
    low_vol = Lens("A", 1.0, 0.9, volatility=0.0)
    high_vol = Lens("B", 1.0, 0.1, volatility=10.0)
    lenses = [low_vol, high_vol]
    result = resolve(lenses, {})
    matrix = result["conflict_matrix"]
    score = matrix["A"]["B"]
    assert score > 0.1
