from typing import Dict, List
from src.lenses import Lens, compute_conflict_matrix, apply_lenses

def infer_execution_bias(lenses: List[Lens]) -> str:
    avg_dominance = sum(l.dominance for l in lenses) / len(lenses)
    if avg_dominance > 0.7:
        return "dominant"
    elif avg_dominance > 0.4:
        return "balanced"
    else:
        return "distributed"

def resolve(lenses: List[Lens], values: Dict[str, float]) -> Dict:
    conflict_matrix = compute_conflict_matrix(lenses)
    output = apply_lenses(lenses, values)
    bias = infer_execution_bias(lenses)
    return {
        "output": output,
        "bias": bias,
        "conflict_matrix": conflict_matrix,
    }
