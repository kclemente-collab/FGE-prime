from dataclasses import dataclass
from typing import Dict, List

@dataclass
class Lens:
    name: str
    weight: float
    dominance: float  # priority in conflicts
    volatility: float = 0.0

def normalize_weights(lenses: List[Lens]) -> List[Lens]:
    total = sum(l.weight for l in lenses)
    if total == 0:
        return lenses
    return [
        Lens(l.name, l.weight / total, l.dominance, l.volatility)
        for l in lenses
    ]

def compute_conflict_matrix(lenses: List[Lens]) -> Dict[str, Dict[str, float]]:
    matrix = {}
    for a in lenses:
        matrix[a.name] = {}
        for b in lenses:
            if a.name == b.name:
                continue
            conflict = abs(a.dominance - b.dominance) * (a.volatility + b.volatility + 0.01)
            matrix[a.name][b.name] = conflict
    return matrix

def apply_lenses(lenses: List[Lens], values: Dict[str, float]) -> float:
    lenses = normalize_weights(lenses)
    result = 0.0
    for l in lenses:
        v = values.get(l.name, 0.0)
        result += v * l.weight
    return result
