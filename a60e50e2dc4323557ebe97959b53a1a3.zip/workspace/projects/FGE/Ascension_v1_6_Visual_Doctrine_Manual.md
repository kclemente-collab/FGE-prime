# Ascension v1.6 Visual Doctrine Manual
**Status: CANON_LOCKED**
**Engine: Masterpiece Compiler v1.1 Visual Elevation Layer**

## Philosophy & Mandate
Ascension v1.6 is the final elevation engine that transforms governed Knowledge Objects into tangible, high-production assets. Every doctrine enforces the FGE truth: **"Broken and more valuable."**

---

## The Seven Locked Doctrines

### 1. Background Doctrine
*   **Technical:** Absolute void black (#080807) base + deep black marble texture overlay + subtle gold kintsugi fracture veins (8–12% opacity).
*   **Mandate:** The void is expensive. Infinite-depth signature is mandatory.

### 2. OFFICIAL METAL RENDERING™ (Ultra-METAL-mode v1.0)
*   **Technical:** PBR 16K, Substance Painter/KeyShot pipeline, high-polygon geometry, edge wear in roughness channel, full anisotropy matrix + HDRI.
*   **Mandate:** Metal is never "perfect." Precision-smelted with micro-scratches and handled edge wear. Mirror reflections must be broken by micro-imperfections.

### 3. OFFICIAL FLESH RENDERING™ (Arnold Cinematic v1.0)
*   **Technical:** Arnold SSS Random Walk v2 (volumetric), micro-pore detail, micro-specular sebum highlights, warm translucent glow on ear edges.
*   **Mandate:** Skin is living and light-absorbing. Peach-fuzz rolloff is mandatory. Avoid plastic specular highlights.

### 4. OFFICIAL OBSIDIAN FLOORING RENDERING™ v1.0
*   **Technical:** Dark obsidian glass skin with subsurface-scattered flesh + conchoidal fracture patterns. Subtle lavender depth in the black.
*   **Mandate:** Dangerous beauty formed in controlled violence. Naturally elastic with luxurious tactile give.

### 5. OFFICIAL CALACATTA KINTSUGI WALL RENDERING™ v1.0
*   **Technical:** Cracked Calacatta marble + liquid gold seams filling stress fractures. Medium SSS for tactile depth.
*   **Mandate:** The history of the surface makes it more precious. Primary for FGE Home territory interiors.

### 6. OFFICIAL EVENING SKY RENDERING™ v1.0
*   **Technical:** Void black branding black + speckled gold stardust particles + precise pinpoint lens flare from behind the viewer.
*   **Mandate:** The FGE night is quiet, expensive, and watching.

### 7. OFFICIAL MARKET RENDERING WRAPPER™ (Masterpiece Realism v1.0)
*   **Technical:** Final realism absorption pass. Ultra-realism, zero anime. 8K–32K output.
*   **Parameters:** `--ar 2:3`, `--strength 140`, `v6` (or equivalent).
*   **Mandate:** Non-negotiable last layer. If it looks like AI, it is a failure.

---

## Compounding Order
Doctrines MUST be applied in this strict sequence:
1. **Background**
2. **Metal**
3. **Flesh**
4. **Flooring**
5. **Walls** (Home)
6. **Evening Sky**
7. **Market Wrapper**

---
**FGE Tower Layer Production • 2026**
